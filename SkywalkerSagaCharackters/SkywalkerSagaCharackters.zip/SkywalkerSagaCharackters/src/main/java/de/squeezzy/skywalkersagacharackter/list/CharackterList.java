package de.squeezzy.skywalkersagacharackter.list;

import de.squeezzy.skywalkersagacharackter.armor.Boots;
import de.squeezzy.skywalkersagacharackter.armor.Chestplate;
import de.squeezzy.skywalkersagacharackter.armor.Leggins;
import de.squeezzy.skywalkersagacharackter.heads.Charakter;
import de.squeezzy.skywalkersagacharackter.heads.Heads;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;

public class CharackterList {
    private  ArrayList<Charakter>charakters = new ArrayList<>();
    public CharackterList() {
        charakters.add(new Charakter(Heads.getAnakin(),Chestplate.getAnakin(),Leggins.getAnakin(),Boots.getAnakin()));
        charakters.add(new Charakter(Heads.getAhsoka(),Chestplate.getAhsoka(),Leggins.getAhsoka(),Boots.getAhsoka()));
        charakters.add(new Charakter(Heads.getLuke(),Chestplate.getLuke(),Leggins.getLuke(),Boots.getLuke()));
        charakters.add(new Charakter(Heads.getYoda(),Chestplate.getYoda(),Leggins.getYoda(),Boots.getYoda()));
        charakters.add(new Charakter(Heads.getRey(),Chestplate.getRey(),Leggins.getRey(),Boots.getRey()));
        charakters.add(new Charakter(Heads.getLeia(),Chestplate.getLeia(),Leggins.getLeia(),Boots.getLeia()));
        charakters.add(new Charakter(Heads.getJarJar(),Chestplate.getJarJar(),Leggins.getJarJar(),Boots.getJarJar()));
        charakters.add(new Charakter(Heads.getEwok(),Chestplate.getEwok(),Leggins.getEwok(),Boots.getEwok()));
        charakters.add(new Charakter(Heads.getRebelPilot(),Chestplate.getRebelPilot(),Leggins.getRebelPilot(),Boots.getRebelPilot()));
        charakters.add(new Charakter(Heads.getRebelHoth(),Chestplate.getRebelHoth(),Leggins.getRebelHoth(),Boots.getRebelHoth()));
        charakters.add(new Charakter(Heads.getReySchrott(),Chestplate.getReySchrott(),Leggins.getReySchrott(),Boots.getReySchrott()));
        charakters.add(new Charakter(Heads.getJawa(),Chestplate.getJawa(),Leggins.getJawa(),Boots.getJawa()));
        charakters.add(new Charakter(Heads.getTusken(),Chestplate.getTusken(),Leggins.getTusken(),Boots.getTusken()));
        charakters.add(new Charakter(Heads.getWicket(),Chestplate.getWicket(),Leggins.getWicket(),Boots.getWicket()));
        charakters.add(new Charakter(Heads.getChiefChirpa(),Chestplate.getChiefChirpa(),Leggins.getChiefChirpa(),Boots.getChiefChirpa()));
        charakters.add(new Charakter(Heads.getHanSolo(),Chestplate.getHanSolo(),Leggins.getHanSolo(),Boots.getHanSolo()));
        charakters.add(new Charakter(Heads.getChewbacca(),Chestplate.getChewbacca(),Leggins.getChewbacca(),Boots.getChewbacca()));
        charakters.add(new Charakter(Heads.getWookie(),Chestplate.getWookie(),Leggins.getWookie(),Boots.getWookie()));
        charakters.add(new Charakter(Heads.getBobaFett(),Chestplate.getBobaFett(),Leggins.getBobaFett(),Boots.getBobaFett()));
        charakters.add(new Charakter(Heads.getHondo(),Chestplate.getHondo(),Leggins.getHondo(),Boots.getHondo()));
        charakters.add(new Charakter(Heads.getJabba(),Chestplate.getJabba(),Leggins.getJabba(),Boots.getJabba()));
        charakters.add(new Charakter(Heads.getTarkin(),Chestplate.getTarkin(),Leggins.getTarkin(),Boots.getTarkin()));
        charakters.add(new Charakter(Heads.getVader(),Chestplate.getVader(),Leggins.getVader(),Boots.getVader()));
        charakters.add(new Charakter(Heads.getR2D2(),Chestplate.getR2D2(),Leggins.getR2D2(),Boots.getR2D2()));
        charakters.add(new Charakter(Heads.getC3PO(),Chestplate.getC3PO(),Leggins.getC3PO(),Boots.getC3PO()));

    }

    public ArrayList<Charakter> getCharakters() {
        return charakters;
    }
}
